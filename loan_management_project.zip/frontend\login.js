// ============================================================
//  Login Page JavaScript
// ============================================================

function togglePassword() {
    const pwd = document.getElementById('password');
    const eye = document.getElementById('eyeIcon');
    if (pwd.type === 'password') {
        pwd.type = 'text';
        eye.classList.replace('bi-eye', 'bi-eye-slash');
    } else {
        pwd.type = 'password';
        eye.classList.replace('bi-eye-slash', 'bi-eye');
    }
}

async function login() {
    const email    = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value;
    const btn      = document.getElementById('loginBtn');

    if (!email || !password) {
        showMsg('Please fill in all fields.', 'danger');
        return;
    }

    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Logging in...';

    try {
        const res = await fetch('http://localhost:8082/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });

        const data = await res.json();

        if (data.status === 'success') {
            // Save session
            localStorage.setItem('slm_session', JSON.stringify({
                email: data.email,
                name: data.name,
                role: data.role,
                id: data.id
            }));
            showMsg('Login successful! Redirecting...', 'success');
            setTimeout(() => {
                window.location.href = 'dashboard.html';
            }, 800);
        } else {
            showMsg(data.message || 'Invalid Email or Password', 'danger');
            btn.disabled = false;
            btn.innerHTML = '<i class="bi bi-box-arrow-in-right me-2"></i>Login';
        }
    } catch (err) {
        // Demo mode: allow login with demo credentials
        console.warn('Backend not available, using demo mode:', err.message);
        if (email === 'admin@smartloan.com' && password === 'admin123') {
            localStorage.setItem('slm_session', JSON.stringify({
                email: 'admin@smartloan.com',
                name: 'System Administrator',
                role: 'Admin',
                id: 1
            }));
            showMsg('Demo mode: Login successful!', 'success');
            setTimeout(() => window.location.href = 'dashboard.html', 800);
        } else if (email && password === 'password123') {
            localStorage.setItem('slm_session', JSON.stringify({
                email: email,
                name: 'Demo Customer',
                role: 'Customer',
                id: 2
            }));
            showMsg('Demo mode: Login successful!', 'success');
            setTimeout(() => window.location.href = 'dashboard.html', 800);
        } else {
            showMsg('Backend server not running. Use admin@smartloan.com / admin123 for demo.', 'warning');
            btn.disabled = false;
            btn.innerHTML = '<i class="bi bi-box-arrow-in-right me-2"></i>Login';
        }
    }
}

function showMsg(msg, type) {
    const el = document.getElementById('loginMsg');
    if (el) {
        el.className = `alert alert-${type} mt-3`;
        el.textContent = msg;
        el.style.display = 'block';
    }
}

function loginWithGoogle() {
    showMsg('Google OAuth requires backend configuration. Using demo login instead.', 'info');
}

// Auto-redirect if already logged in
window.addEventListener('DOMContentLoaded', () => {
    const session = localStorage.getItem('slm_session');
    if (session) {
        window.location.href = 'dashboard.html';
    }

    // Allow Enter key to submit
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') login();
    });
});
