package com.smartloan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartloanmanagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
