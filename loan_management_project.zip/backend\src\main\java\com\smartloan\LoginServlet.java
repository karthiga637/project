package com.smartloan;

import java.io.*;
import java.util.Map;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Headers", "Content-Type");

        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = request.getReader()) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
        }

        String json = sb.toString();
        try {
            String email    = json.split("\"email\":\"")[1].split("\"")[0];
            String password = json.split("\"password\":\"")[1].split("\"")[0];

            CustomerDAO dao = new CustomerDAO();
            boolean ok = dao.login(email, password);

            if (ok) {
                Map<String, Object> cust = dao.getCustomerByEmail(email);
                String role = cust != null ? (String) cust.get("role") : "Customer";
                String name = cust != null
                        ? cust.get("firstName") + " " + cust.get("lastName") : "";
                int id = cust != null ? (Integer) cust.get("id") : 0;
                response.getWriter().write(
                    "{\"status\":\"success\",\"role\":\"" + role + "\",\"name\":\"" + name
                    + "\",\"email\":\"" + email + "\",\"id\":" + id + "}");
            } else {
                response.setStatus(401);
                response.getWriter().write("{\"status\":\"failed\",\"message\":\"Invalid email or password\"}");
            }
        } catch (Exception e) {
            response.setStatus(500);
            response.getWriter().write("{\"status\":\"error\",\"message\":\"" + e.getMessage() + "\"}");
        }
    }

    protected void doOptions(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        res.setHeader("Access-Control-Allow-Origin", "*");
        res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
        res.setHeader("Access-Control-Allow-Headers", "Content-Type");
        res.setStatus(200);
    }
}