// ============================================================
//  AI Insights Page JavaScript
// ============================================================

const API = 'http://localhost:8082';

const DEMO_INSIGHTS = [
    {
        loanId: 1, customerName: 'Priya Sharma', loanType: 'Home Loan', loanAmount: 1500000,
        outstanding: 1200000, emiAmount: 14751, overdueCount: 2, paidCount: 18, totalEmis: 180,
        riskScore: 75, riskLevel: 'High', recommendation: 'Immediate follow-up required. 2 overdue EMIs detected.',
        defaultProbability: 68
    },
    {
        loanId: 2, customerName: 'Vijay Raj', loanType: 'Vehicle Loan', loanAmount: 500000,
        outstanding: 350000, emiAmount: 10490, overdueCount: 0, paidCount: 22, totalEmis: 60,
        riskScore: 45, riskLevel: 'Medium', recommendation: 'Monitor closely. Outstanding balance still significant.',
        defaultProbability: 41
    },
    {
        loanId: 3, customerName: 'Arun Velmurugan', loanType: 'Education Loan', loanAmount: 450000,
        outstanding: 250000, emiAmount: 9330, overdueCount: 0, paidCount: 22, totalEmis: 60,
        riskScore: 22, riskLevel: 'Low', recommendation: 'Performing well. Regular monitoring is sufficient.',
        defaultProbability: 20
    },
    {
        loanId: 4, customerName: 'Rahul Kumar', loanType: 'Personal Loan', loanAmount: 200000,
        outstanding: 130000, emiAmount: 6495, overdueCount: 2, paidCount: 20, totalEmis: 36,
        riskScore: 60, riskLevel: 'Medium', recommendation: 'Two EMIs overdue. Offer flexible payment plan.',
        defaultProbability: 54
    }
];

// ── Helpers ────────────────────────────────────────────────────────────────────
function fmt(n) { return '₹' + Number(n).toLocaleString('en-IN'); }

// ── Load AI Insights ───────────────────────────────────────────────────────────
async function loadInsights() {
    let insights = null;
    try {
        const res = await fetch(`${API}/ai-insights`);
        insights = await res.json();
    } catch { insights = DEMO_INSIGHTS; }

    if (!insights || insights.length === 0) {
        document.getElementById('insightsContainer').innerHTML =
            '<div class="alert alert-info">No active loans found for AI analysis.</div>';
        return;
    }

    renderRiskCards(insights);
    renderRiskChart(insights);
    renderRiskTable(insights);
    updateRiskSummary(insights);
}

// ── Risk Summary Cards ─────────────────────────────────────────────────────────
function updateRiskSummary(insights) {
    const high   = insights.filter(i => i.riskLevel === 'High').length;
    const medium = insights.filter(i => i.riskLevel === 'Medium').length;
    const low    = insights.filter(i => i.riskLevel === 'Low').length;
    const avgScore = Math.round(insights.reduce((s, i) => s + i.riskScore, 0) / insights.length);

    const set = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v; };
    set('highRiskCount', high);
    set('mediumRiskCount', medium);
    set('lowRiskCount', low);
    set('avgRiskScore', avgScore + '%');
}

// ── AI Insight Cards ───────────────────────────────────────────────────────────
function renderRiskCards(insights) {
    const container = document.getElementById('insightsContainer');
    if (!container) return;

    container.innerHTML = insights.map(item => {
        const level = (item.riskLevel || 'low').toLowerCase();
        const levelColors = { high: 'danger', medium: 'warning', low: 'success' };
        const color = levelColors[level] || 'secondary';
        const icon  = level === 'high' ? 'exclamation-triangle-fill' : level === 'medium' ? 'exclamation-circle-fill' : 'check-circle-fill';

        return `
        <div class="ai-insight-card ${level} mb-3">
            <div class="d-flex justify-content-between align-items-start mb-2">
                <div>
                    <h6 class="mb-0 fw-bold">${item.customerName}</h6>
                    <small class="text-muted">${item.loanType} — #${item.loanId}</small>
                </div>
                <span class="badge bg-${color} rounded-pill">
                    <i class="bi bi-${icon} me-1"></i>${item.riskLevel} Risk
                </span>
            </div>
            <div class="row g-2 mb-3">
                <div class="col-6 col-md-3">
                    <div class="p-2 bg-light rounded text-center">
                        <div class="fw-bold">${fmt(item.loanAmount)}</div>
                        <small class="text-muted">Loan Amount</small>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="p-2 bg-light rounded text-center">
                        <div class="fw-bold">${fmt(item.outstanding)}</div>
                        <small class="text-muted">Outstanding</small>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="p-2 bg-light rounded text-center">
                        <div class="fw-bold text-danger">${item.overdueCount}</div>
                        <small class="text-muted">Overdue EMIs</small>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="p-2 bg-light rounded text-center">
                        <div class="fw-bold">${item.paidCount}/${item.totalEmis}</div>
                        <small class="text-muted">Paid/Total</small>
                    </div>
                </div>
            </div>
            <div class="mb-2">
                <div class="d-flex justify-content-between mb-1">
                    <small class="fw-bold">Risk Score</small>
                    <small class="fw-bold text-${color}">${item.riskScore}%</small>
                </div>
                <div class="progress" style="height:12px;border-radius:6px">
                    <div class="progress-bar bg-${color}" style="width:${item.riskScore}%;border-radius:6px"></div>
                </div>
            </div>
            <div class="mt-2 p-2 rounded" style="background:rgba(0,0,0,0.04)">
                <small><i class="bi bi-cpu me-1 text-${color}"></i><strong>AI Recommendation:</strong> ${item.recommendation}</small>
            </div>
            <div class="mt-2">
                <small class="text-muted">Default Probability: </small>
                <strong class="text-${color}">${item.defaultProbability}%</strong>
            </div>
        </div>`;
    }).join('');
}

// ── Risk Distribution Chart ────────────────────────────────────────────────────
function renderRiskChart(insights) {
    const ctx = document.getElementById('riskChart');
    if (!ctx) return;

    const high   = insights.filter(i => i.riskLevel === 'High').length;
    const medium = insights.filter(i => i.riskLevel === 'Medium').length;
    const low    = insights.filter(i => i.riskLevel === 'Low').length;

    if (window._riskChart) window._riskChart.destroy();

    window._riskChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['High Risk', 'Medium Risk', 'Low Risk'],
            datasets: [{
                data: [high, medium, low],
                backgroundColor: ['#dc3545', '#ffc107', '#198754'],
                borderWidth: 3,
                borderColor: '#fff'
            }]
        },
        options: {
            responsive: true,
            cutout: '60%',
            plugins: { legend: { position: 'bottom' } }
        }
    });

    // Bar chart of risk scores
    const ctx2 = document.getElementById('riskScoreChart');
    if (!ctx2) return;

    if (window._riskScoreChart) window._riskScoreChart.destroy();

    window._riskScoreChart = new Chart(ctx2, {
        type: 'bar',
        data: {
            labels: insights.map(i => i.customerName.split(' ')[0]),
            datasets: [{
                label: 'Risk Score (%)',
                data: insights.map(i => i.riskScore),
                backgroundColor: insights.map(i => {
                    if (i.riskLevel === 'High') return '#dc3545';
                    if (i.riskLevel === 'Medium') return '#ffc107';
                    return '#198754';
                }),
                borderRadius: 8
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: { beginAtZero: true, max: 100, ticks: { callback: v => v + '%' } },
                x: { grid: { display: false } }
            },
            plugins: { legend: { display: false } }
        }
    });
}

// ── Risk Table ─────────────────────────────────────────────────────────────────
function renderRiskTable(insights) {
    const tbody = document.getElementById('riskTableBody');
    if (!tbody) return;

    tbody.innerHTML = insights.map(i => {
        const m = { High: 'danger', Medium: 'warning', Low: 'success' };
        const c = m[i.riskLevel] || 'secondary';
        return `
        <tr>
            <td>${i.customerName}</td>
            <td>${i.loanType}</td>
            <td>${fmt(i.loanAmount)}</td>
            <td class="text-danger">${i.overdueCount}</td>
            <td>
                <div class="progress" style="height:10px">
                    <div class="progress-bar bg-${c}" style="width:${i.riskScore}%"></div>
                </div>
                <small>${i.riskScore}%</small>
            </td>
            <td><span class="badge bg-${c}">${i.riskLevel}</span></td>
            <td><small>${i.recommendation}</small></td>
        </tr>`;
    }).join('');
}

// ── Init ───────────────────────────────────────────────────────────────────────
window.addEventListener('DOMContentLoaded', () => {
    if (!localStorage.getItem('slm_session')) { window.location.href = 'login.html'; return; }
    const session = JSON.parse(localStorage.getItem('slm_session'));
    const nameEl = document.getElementById('user-name');
    if (nameEl) nameEl.textContent = session.name || session.email;
    loadInsights();
});
