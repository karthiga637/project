// ============================================================
//  Dashboard Page JavaScript
// ============================================================

const API = 'http://localhost:8082';

// ── Demo Data (used when backend is unavailable) ───────────────────────────────
const DEMO = {
    stats: { totalCustomers: 48, totalLoans: 127, totalLoanAmount: 45600000, overdueEMIs: 6, activeLoans: 98, approvedLoans: 12, paidEMIs: 820 },
    recentLoans: [
        { id: 1, customerName: 'Rahul Kumar', loanType: 'Personal Loan', loanAmount: 200000, emiAmount: 6495, outstandingBalance: 130000, status: 'Active' },
        { id: 2, customerName: 'Priya Sharma', loanType: 'Home Loan', loanAmount: 1500000, emiAmount: 14751, outstandingBalance: 1200000, status: 'Active' },
        { id: 3, customerName: 'Arun Velmurugan', loanType: 'Education Loan', loanAmount: 450000, emiAmount: 9330, outstandingBalance: 250000, status: 'Active' },
        { id: 4, customerName: 'Meena Krishnan', loanType: 'Business Loan', loanAmount: 800000, emiAmount: 21067, outstandingBalance: 0, status: 'Completed' },
        { id: 5, customerName: 'Vijay Raj', loanType: 'Vehicle Loan', loanAmount: 500000, emiAmount: 10490, outstandingBalance: 350000, status: 'Active' }
    ]
};

// ── Helpers ────────────────────────────────────────────────────────────────────
function fmt(n) { return '₹' + Number(n).toLocaleString('en-IN'); }
function badge(s) {
    const m = { 'Active':'success','Completed':'primary','Overdue':'danger','Pending':'warning','Approved':'info','Defaulted':'dark' };
    return `<span class="badge bg-${m[s]||'secondary'}">${s}</span>`;
}

// ── Load Stats Cards ───────────────────────────────────────────────────────────
async function loadStats() {
    let stats = null;
    try {
        const res = await fetch(`${API}/customers?action=stats`);
        stats = await res.json();
    } catch { stats = DEMO.stats; }

    document.getElementById('totalCustomers').textContent  = stats.totalCustomers || 0;
    document.getElementById('totalLoans').textContent      = stats.totalLoans || 0;
    document.getElementById('activeLoans').textContent     = stats.activeLoans || 0;
    document.getElementById('overdueEMIs').textContent     = stats.overdueEMIs || 0;
    document.getElementById('totalLoanAmt').textContent    = fmt(stats.totalLoanAmount || 0);
    document.getElementById('paidEMIs').textContent        = stats.paidEMIs || 0;
}

// ── Load Recent Loans Table ────────────────────────────────────────────────────
async function loadRecentLoans() {
    let loans = null;
    try {
        const res = await fetch(`${API}/loans`);
        loans = await res.json();
    } catch { loans = DEMO.recentLoans; }

    const tbody = document.getElementById('recentLoansBody');
    if (!tbody) return;

    const top5 = (loans || []).slice(0, 5);
    tbody.innerHTML = top5.map((l, i) => `
        <tr class="fade-in" style="animation-delay:${i*0.08}s">
            <td><strong>#${l.id}</strong></td>
            <td>${l.customerName || '-'}</td>
            <td>${l.loanType || '-'}</td>
            <td>${fmt(l.loanAmount)}</td>
            <td>${fmt(l.emiAmount)}</td>
            <td>${fmt(l.outstandingBalance)}</td>
            <td>${badge(l.status)}</td>
        </tr>
    `).join('');
}

// ── EMI Status Chart (Doughnut) ────────────────────────────────────────────────
async function loadEMIChart() {
    let stats = null;
    try {
        const res = await fetch(`${API}/customers?action=stats`);
        stats = await res.json();
    } catch { stats = DEMO.stats; }

    const ctx = document.getElementById('emiChart');
    if (!ctx) return;

    const paid    = stats.paidEMIs || 820;
    const overdue = stats.overdueEMIs || 6;
    const pending = Math.max((stats.totalLoans || 127) * 5 - paid - overdue, 0);

    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Paid', 'Pending', 'Overdue'],
            datasets: [{
                data: [paid, pending, overdue],
                backgroundColor: ['#198754', '#ffc107', '#dc3545'],
                borderWidth: 2,
                borderColor: '#fff'
            }]
        },
        options: {
            responsive: true,
            cutout: '65%',
            plugins: {
                legend: { position: 'bottom', labels: { padding: 15, font: { size: 13 } } }
            }
        }
    });
}

// ── Loan Type Chart (Bar) ──────────────────────────────────────────────────────
async function loadLoanTypeChart() {
    let loans = null;
    try {
        const res = await fetch(`${API}/loans`);
        loans = await res.json();
    } catch { loans = DEMO.recentLoans; }

    const ctx = document.getElementById('loanTypeChart');
    if (!ctx) return;

    const counts = {};
    (loans || []).forEach(l => {
        counts[l.loanType] = (counts[l.loanType] || 0) + 1;
    });

    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: Object.keys(counts),
            datasets: [{
                label: 'Number of Loans',
                data: Object.values(counts),
                backgroundColor: ['#0d6efd','#198754','#fd7e14','#dc3545','#6f42c1','#20c997'],
                borderRadius: 8,
                borderSkipped: false
            }]
        },
        options: {
            responsive: true,
            plugins: { legend: { display: false } },
            scales: {
                y: { beginAtZero: true, ticks: { stepSize: 1 } },
                x: { grid: { display: false } }
            }
        }
    });
}

// ── Notifications ──────────────────────────────────────────────────────────────
function loadNotifications() {
    const notifications = [
        { type: 'warning', icon: 'exclamation-triangle-fill', color: 'warning', title: '2 EMIs are Overdue', msg: 'Immediate follow-up required for overdue payments.' },
        { type: 'info', icon: 'bell-fill', color: 'info', title: '5 EMIs due this week', msg: 'Send reminders to customers for upcoming payments.' },
        { type: 'success', icon: 'check-circle-fill', color: 'success', title: '3 loans completed', msg: 'Congratulations! Three customers completed their loans.' }
    ];

    const container = document.getElementById('notificationList');
    if (!container) return;

    container.innerHTML = notifications.map(n => `
        <div class="notification-item">
            <div class="notification-icon bg-${n.color} bg-opacity-10 text-${n.color}">
                <i class="bi bi-${n.icon}"></i>
            </div>
            <div>
                <strong style="font-size:0.9rem">${n.title}</strong>
                <p class="mb-0 text-muted" style="font-size:0.82rem">${n.msg}</p>
            </div>
        </div>
    `).join('');
}

// ── Activity Timeline ──────────────────────────────────────────────────────────
function loadActivityTimeline() {
    const activities = [
        { icon: 'cash-stack', color: 'primary', text: 'New loan added for <b>Rahul Kumar</b>', time: '2 hours ago' },
        { icon: 'credit-card', color: 'success', text: 'EMI #30 paid by <b>Rahul Kumar</b>', time: '5 hours ago' },
        { icon: 'person-plus', color: 'info', text: 'New customer <b>Sita Devi</b> registered', time: 'Yesterday' },
        { icon: 'exclamation-triangle', color: 'danger', text: 'EMI overdue for <b>Priya Sharma</b>', time: '2 days ago' },
        { icon: 'check2-circle', color: 'success', text: 'Loan completed for <b>Meena Krishnan</b>', time: '3 days ago' }
    ];

    const container = document.getElementById('activityTimeline');
    if (!container) return;

    container.innerHTML = activities.map(a => `
        <div class="d-flex align-items-start gap-3 mb-3">
            <div class="notification-icon bg-${a.color} bg-opacity-10 text-${a.color}">
                <i class="bi bi-${a.icon}"></i>
            </div>
            <div>
                <p class="mb-0" style="font-size:0.88rem">${a.text}</p>
                <small class="text-muted">${a.time}</small>
            </div>
        </div>
    `).join('');
}

// ── Set User Info ──────────────────────────────────────────────────────────────
function setUser() {
    const s = localStorage.getItem('slm_session');
    if (!s) return;
    const session = JSON.parse(s);
    const el = document.getElementById('user-name');
    if (el) el.textContent = session.name || session.email || 'Admin';
}

// ── Init ───────────────────────────────────────────────────────────────────────
window.addEventListener('DOMContentLoaded', () => {
    // Auth check
    if (!localStorage.getItem('slm_session')) {
        window.location.href = 'login.html';
        return;
    }
    setUser();
    loadStats();
    loadRecentLoans();
    loadEMIChart();
    loadLoanTypeChart();
    loadNotifications();
    loadActivityTimeline();
});